# Employee Portal (Django)

## Run locally
    pip install -r requirements.txt
    python manage.py migrate
    python manage.py shell < seed.py     # demo users (optional)
    python manage.py runserver

## Deploy on Render (Web Service)
- Build command: `./build.sh`
- Start command: `gunicorn portal.wsgi`
- Environment variables:
  - `SECRET_KEY` = any long random string
  - `DEBUG` = False
  - `DJANGO_SUPERUSER_USERNAME` = hr
  - `DJANGO_SUPERUSER_PASSWORD` = a strong password
  - `DJANGO_SUPERUSER_EMAIL` = you@example.com
  - `PYTHON_VERSION` = 3.12.3

HR = any user with `is_staff=True`. Add employees at /admin/ -> Users.
Note: free tier wipes SQLite + uploads on restart/redeploy (fine for demo).
