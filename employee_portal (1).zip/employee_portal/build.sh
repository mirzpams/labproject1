#!/usr/bin/env bash
set -o errexit
pip install -r requirements.txt
python manage.py collectstatic --noinput
python manage.py migrate
# creates the HR login from env vars; skips if it already exists
python manage.py createsuperuser --noinput || true
