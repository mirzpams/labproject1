from django.contrib import admin
from .models import LeaveRequest, Document, Announcement

admin.site.register(LeaveRequest)
admin.site.register(Document)
admin.site.register(Announcement)
