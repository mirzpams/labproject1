from django import forms
from .models import LeaveRequest, Document, Announcement


class LeaveForm(forms.ModelForm):
    class Meta:
        model = LeaveRequest
        fields = ['leave_type', 'start_date', 'end_date', 'reason']
        widgets = {
            'start_date': forms.DateInput(attrs={'type': 'date'}),
            'end_date': forms.DateInput(attrs={'type': 'date'}),
            'reason': forms.Textarea(attrs={'rows': 3}),
        }

    def clean(self):
        data = super().clean()
        s, e = data.get('start_date'), data.get('end_date')
        if s and e and e < s:
            raise forms.ValidationError('End date cannot be before start date.')
        return data


class DocumentForm(forms.ModelForm):
    class Meta:
        model = Document
        fields = ['title', 'file']


class AnnouncementForm(forms.ModelForm):
    class Meta:
        model = Announcement
        fields = ['title', 'body']
        widgets = {'body': forms.Textarea(attrs={'rows': 3})}
