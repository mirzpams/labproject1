from django.db import models
from django.contrib.auth.models import User


class LeaveRequest(models.Model):
    TYPES = [('annual', 'Annual'), ('sick', 'Sick'), ('casual', 'Casual'), ('unpaid', 'Unpaid')]
    STATUSES = [('pending', 'Pending'), ('approved', 'Approved'), ('rejected', 'Rejected')]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    leave_type = models.CharField(max_length=10, choices=TYPES)
    start_date = models.DateField()
    end_date = models.DateField()
    reason = models.TextField(blank=True)
    status = models.CharField(max_length=10, choices=STATUSES, default='pending')
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created']

    def __str__(self):
        return f'{self.user} - {self.leave_type} ({self.status})'


class Document(models.Model):
    title = models.CharField(max_length=150)
    file = models.FileField(upload_to='docs/')
    uploaded = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-uploaded']

    def __str__(self):
        return self.title


class Announcement(models.Model):
    title = models.CharField(max_length=150)
    body = models.TextField()
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created']

    def __str__(self):
        return self.title
