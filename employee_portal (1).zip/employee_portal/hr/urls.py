from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('documents/', views.documents, name='documents'),
    path('leave/', views.leave_list, name='leave_list'),
    path('leave/new/', views.leave_new, name='leave_new'),
    path('leave/<int:pk>/<str:action>/', views.leave_decide, name='leave_decide'),
]
