from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST

from .forms import LeaveForm, DocumentForm, AnnouncementForm
from .models import LeaveRequest, Document, Announcement

hr_only = user_passes_test(lambda u: u.is_staff)  # HR = staff users


@login_required
def home(request):
    form = AnnouncementForm()
    if request.method == 'POST' and request.user.is_staff:
        form = AnnouncementForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    return render(request, 'hr/home.html', {'form': form, 'items': Announcement.objects.all()})


@login_required
def documents(request):
    form = DocumentForm()
    if request.method == 'POST' and request.user.is_staff:
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('documents')
    return render(request, 'hr/documents.html', {'form': form, 'items': Document.objects.all()})


@login_required
def leave_list(request):
    qs = LeaveRequest.objects.select_related('user')
    if not request.user.is_staff:
        qs = qs.filter(user=request.user)
    return render(request, 'hr/leave_list.html', {'items': qs})


@login_required
def leave_new(request):
    form = LeaveForm(request.POST or None)
    if form.is_valid():
        leave = form.save(commit=False)
        leave.user = request.user
        leave.save()
        return redirect('leave_list')
    return render(request, 'hr/leave_form.html', {'form': form})


@login_required
@hr_only
@require_POST
def leave_decide(request, pk, action):
    leave = get_object_or_404(LeaveRequest, pk=pk)
    if action in ('approved', 'rejected'):
        leave.status = action
        leave.save()
    return redirect('leave_list')
