"""Run: python manage.py shell < seed.py  -> creates demo users + sample data"""
from django.contrib.auth.models import User
from hr.models import Announcement

if not User.objects.filter(username='hr').exists():
    User.objects.create_user('hr', password='hr12345', is_staff=True, is_superuser=True)
if not User.objects.filter(username='ali').exists():
    User.objects.create_user('ali', password='ali12345')
if not Announcement.objects.exists():
    Announcement.objects.create(title='Welcome', body='Welcome to the employee portal.')
print('Done. HR login: hr / hr12345 | Employee login: ali / ali12345')
